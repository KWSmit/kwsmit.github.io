////////////////////////////////////////////////////////////////////
// Function to set the robot ready for the game:
// Usage of EV3-buttons:
//		UP-button				- Move pen to the left
//		DOWN-button			- Move pen to the right
//		RIGHT-buttton		- Tilt pen up
//		LEFT-button			- Tilt pen down
//		ENTER-button		- Start game
////////////////////////////////////////////////////////////////////
bool InitTTT()

{
	bool GameReady = false;
	float BatteryLive;
	const float LowBattery = 6.50;

	playSoundFile("Activate");

	// Check battery voltage
	BatteryLive = getBatteryVoltage();
	if (BatteryLive <= LowBattery)
	{
		playSoundFile("Error");
		displayCenteredBigTextLine(3, "WARNING/nBattery low, please recharge!!");
		return GameReady;
	}

	// Draw TTT field on EV3 display
	drawLine(25,42,151,42);
	drawLine(24,84,151,84);
	drawLine(67,0,67,126);
	drawLine(109,0,109,126);

	while (true)
	{
		if(getButtonPress(1) == 1)
		{
			// UP-button pressed: move pen to left
			setMotorSpeed(Shift,50);
		}
		else if (getButtonPress(3) == 1)
		{
			// DOWN-button pressed: move pen to right
			setMotorSpeed(Shift,-50);
		}
		else if (getButtonPress(4) == 1)
		{
			//RIGHT-button pressed: pen up
			setMotorSpeed(Shift,0);
			moveMotorTarget(TiltPen,45,-10);
		}
		else if (getButtonPress(5) == 1)
		{
			//LEFT-button pressed: pen down
			setMotorSpeed(Shift,0);
			moveMotorTarget(TiltPen,45,10);
		}
		else if (getButtonPress(2) == 1)
		{
			//ENTER-button pressed: start game
			setMotorSpeed(Shift,0);
			GameReady = true;
			break;
		}
		else
		{
			setMotorSpeed(Shift,0);
		}
	}
	return GameReady;
}

//////////////////////////////////////////////////////////////////
// Function to draw the lines of the TicTacToe field:
//////////////////////////////////////////////////////////////////
void DrawTTTField()
{

	// Vertical lines
	moveMotorTarget(Drive,5000,-100);		//Drive forward (4000)
	moveMotorTarget(Shift,4500,100); 		//Shift left to first line
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);
	moveMotorTarget(TiltPen,45,5);			//Pen down
	waitUntilMotorStop(TiltPen);
	moveMotorTarget(Drive,3100,100);		//Drive backwards (2100)
	waitUntilMotorStop(Drive);
	moveMotorTarget(TiltPen,45,-10);		//Pen up
	waitUntilMotorStop(TiltPen);
	moveMotorTarget(Shift,4000,100);		//Shift left to second line
	waitUntilMotorStop(Shift);
	moveMotorTarget(TiltPen,45,5);			//Pen down
	waitUntilMotorStop(TiltPen);
	moveMotorTarget(Drive,3100,-100);		//Drive forward (2100)
	waitUntilMotorStop(Drive);
	moveMotorTarget(TiltPen,45,-10);		//Pen up
	waitUntilMotorStop(TiltPen);
	// Horizontal lines
	moveMotorTarget(Drive,1200,100);			//Drive backwards to first horizontal line (650)
	moveMotorTarget(Shift,3500,100);		//Shift left to end
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);
	moveMotorTarget(TiltPen,45,5);			//Pen down
	waitUntilMotorStop(TiltPen);
	moveMotorTarget(Shift,12000,-100);	//Shift right to end
	waitUntilMotorStop(Shift);
	moveMotorTarget(TiltPen,45,-10);		//Pen up
	waitUntilMotorStop(TiltPen);
	moveMotorTarget(Drive,1000,100);			//Drive backwards to second horizontal line (800)
	waitUntilMotorStop(Drive);
	moveMotorTarget(TiltPen,45,5);			//Pen down
	waitUntilMotorStop(TiltPen);
	moveMotorTarget(Shift,12000,100);		//Shift left to end
	waitUntilMotorStop(Shift);
	moveMotorTarget(TiltPen,45,-10);		//Pen up
	moveMotorTarget(Shift,12000,-100);	//Shift right to end
	moveMotorTarget(Drive,2800,100);		//Drive backward to start position (2550)
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);

}

///////////////////////////////////////////////////////////////////////////
// Function to detect all fields
//
// Fields	(0,0) - (0,1) - (0,2)		 ^
//				(1,0) - (1,1) - (1,2)		/|\	Driving direction robot
//				(2,0) - (2,1) - (2,2)		 |
//
///////////////////////////////////////////////////////////////////////////

void DetectAllFields()
{
	int iVal = 0;	// Value Color sensor

	// Move to field (0,0)
	moveMotorTarget(Drive,8200,-100); //(7000)
	moveMotorTarget(Shift,10500,100);
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[0][0] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(0,0) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[0][0] = 2;
			TTTValuesSet[0][0] = true;
			displayBigStringAt(Row[0],Col[0],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[0][0] = 0;
			displayBigStringAt(Row[0],Col[0]," ");
		}
		else
		{
			TTTValues[0][0] = 1;
			TTTValuesSet[0][0] = true;
			displayBigStringAt(Row[0],Col[0],"X");
		}
	}

	// Move to field (0,1)
	moveMotorTarget(Shift,4400,-100);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[0][1] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(0,1) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[0][1] = 2;
			TTTValuesSet[0][1] = true;
			displayBigStringAt(Row[0],Col[1],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[0][1] = 0;
			displayBigStringAt(Row[0],Col[1]," ");
		}
		else
		{
			TTTValues[0][1] = 1;
			TTTValuesSet[0][1] = true;
			displayBigStringAt(Row[0],Col[1],"X");
		}
	}

	// Move to field (0,2)
	moveMotorTarget(Shift,4300,-100);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[0][2] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(0,2) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[0][2] = 2;
			TTTValuesSet[0][2] = true;
			displayBigStringAt(Row[0],Col[2],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[0][2] = 0;
			displayBigStringAt(Row[0],Col[2]," ");
		}
		else
		{
			TTTValues[0][2] = 1;
			TTTValuesSet[0][2] = true;
			displayBigStringAt(Row[0],Col[2],"X");
		}
	}

	// Move to field (1,2)
	moveMotorTarget(Drive,1000,100); //(800)
	waitUntilMotorStop(Drive);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[1][2] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(1,2) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[1][2] = 2;
			TTTValuesSet[1][2] = true;
			displayBigStringAt(Row[1],Col[2],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[1][2] = 0;
			displayBigStringAt(Row[1],Col[2]," ");
		}
		else
		{
			TTTValues[1][2] = 1;
			TTTValuesSet[1][2] = true;
			displayBigStringAt(Row[1],Col[2],"X");
		}
	}
	// Move to field (1,1)
	//moveMotorTarget(Shift,4500,100);
	moveMotorTarget(Shift,4300,100);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[1][1] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(1,1) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[1][1] = 2;
			TTTValuesSet[1][1] = true;
			displayBigStringAt(Row[1],Col[1],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[1][1] = 0;
			displayBigStringAt(Row[1],Col[1]," ");
		}
		else
		{
			TTTValues[1][1] = 1;
			TTTValuesSet[1][1] = true;
			displayBigStringAt(Row[1],Col[1],"X");
		}
	}

	// Move to field (1,0)
	moveMotorTarget(Shift,4400,100);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[1][0] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(1,0) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[1][0] = 2;
			TTTValuesSet[1][0] = true;
			displayBigStringAt(Row[1],Col[0],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[1][0] = 0;
			displayBigStringAt(Row[1],Col[0]," ");
		}
		else
		{
			TTTValues[1][0] = 1;
			TTTValuesSet[1][0] = true;
			displayBigStringAt(Row[1],Col[0],"X");
		}
	}

		// Move to field (2,0)
	moveMotorTarget(Drive,900,100); //(750)
	waitUntilMotorStop(Drive);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[2][0] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(2,0) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[2][0] = 2;
			TTTValuesSet[2][0] = true;
			displayBigStringAt(Row[2],Col[0],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[2][0] = 0;
			displayBigStringAt(Row[2],Col[0]," ");
		}
		else
		{
			TTTValues[2][0] = 1;
			TTTValuesSet[2][0] = true;
			displayBigStringAt(Row[2],Col[0],"X");
		}
	}

	// Move to field (2,1)
	moveMotorTarget(Shift,4400,-100);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[2][1] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(2,1) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[2][1] = 2;
			TTTValuesSet[2][1] = true;
			displayBigStringAt(Row[2],Col[1],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[2][1] = 0;
			displayBigStringAt(Row[2],Col[1]," ");
		}
		else
		{
			TTTValues[2][1] = 1;
			TTTValuesSet[2][1] = true;
			displayBigStringAt(Row[2],Col[1],"X");
		}
	}

	// Move to field (2,2)
	//moveMotorTarget(Shift,4500,-100);
	moveMotorTarget(Shift,4300,-100);
	waitUntilMotorStop(Shift);
	sleep(10);
	// Detect and display value if not set already
	if (TTTValuesSet[2][2] == false)
	{
		iVal = SensorValue[Color];
		writeDebugStreamLine("(2,2) = %5d",iVal);
		if (iVal < Treshold1)
		{
			TTTValues[2][2] = 2;
			TTTValuesSet[2][2] = true;
			displayBigStringAt(Row[2],Col[2],"O");
		}
		else if (iVal > Treshold2)
		{
			TTTValues[2][2] = 0;
			displayBigStringAt(Row[2],Col[2]," ");
		}
		else
		{
			TTTValues[2][2] = 1;
			TTTValuesSet[2][2] = true;
			displayBigStringAt(Row[2],Col[2],"X");
		}
	}

	//Back to startposition
	moveMotorTarget(Drive,6300,100); //(5450)
	//moveMotorTarget(Shift,1000,-100);
	moveMotorTarget(Shift,1800,-100);
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);

}

//////////////////////////////////////////////////////////////////
// Function to draw a cross on a given row and column
//////////////////////////////////////////////////////////////////
void DrawCross(int Rw, int Column)
{

	//const int R[3] = {3900,3100,2400};
	const int R[3] = {4900,3900,2900}; // {5000,3200,2500}
	const int C[3] = {11800,8200,4200};

	// Move to upper-left side of cross
	moveMotorTarget(Drive,R[Rw],-100);
	moveMotorTarget(Shift,C[Column],100);
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);

	// Pen down
	moveMotorTarget(TiltPen,45,5);
	waitUntilMotorStop(TiltPen);

	// Draw to lower-right side of cross
	moveMotorTarget(Shift,4000,-100);
	sleep(500);
	moveMotorTarget(Drive,1000,40);	//(500)
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);

	// Pen up
	moveMotorTarget(TiltPen,45,-5);
	waitUntilMotorStop(TiltPen);

	// Move to upper-right side of cross
	moveMotorTarget(Drive,1000,-100);	//(500)
	waitUntilMotorStop(Drive);

	// Pen down
	moveMotorTarget(TiltPen,45,5);
	waitUntilMotorStop(TiltPen);

	// Draw to lower-left side of cross
	moveMotorTarget(Shift,4000,100);
	sleep(500);
	moveMotorTarget(Drive,1000,40);	//(500)
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);

	// Pen up
	moveMotorTarget(TiltPen,45,-5);
	waitUntilMotorStop(TiltPen);

	// Move to starting position
	moveMotorTarget(Drive,R[Rw]-1000,100);
	moveMotorTarget(Shift,C[Column],-100);
	waitUntilMotorStop(Drive);
	waitUntilMotorStop(Shift);

	// Set TTTValues
	TTTValues[Rw][Column] = 1;
	TTTValuesSet[Rw][Column] = true;

	// Update EV3 Display
	displayBigStringAt(Row[Rw],Col[Column],"X");

}

/////////////////////////////////////////////////////////////////
// Function to check whether there are three similar symbols
// on a row,thus whether there is a winner or not
/////////////////////////////////////////////////////////////////

GameState CheckGameState(int Round)
{
	int i,j;
	int Sum;
	bool Blanc;
	GameState retVal;

	// Check horizontal rows
	for (i=0;i<=2;++i)
	{
		Sum = 0;
		Blanc = false;
		for(j=0;j<=2;++j)
		{
			Sum = Sum + TTTValues[i][j];
			if (TTTValues[i][j]==0){Blanc = true;}
		}
		if (Sum == 0)
		{
			// All fields empty
		}
		else if (Sum == 3 & Blanc == false)
		{
			// Three X's on a row, EV3 is winner
			retVal = Won;
			return retVal;
		}
		else if (Sum == 6)
		{
			// Three O's on a row, opponent is winner
			retVal = Lost;
			return retVal;
		}
	}

	// Check vertical rows
	for (j=0;j<=2;++j)
	{
		Sum = 0;
		Blanc = false;
		for (i=0;i<=2;++i)
		{
			Sum = Sum + TTTValues[i][j];
			if (TTTValues[i][j]==0){Blanc = true;}
		}
		if (Sum == 0)
		{
			// All fields empty
		}
		else if (Sum == 3 & Blanc == false)
		{
			// Three X's on a row, EV3 is winner
			retVal = Won;
			return retVal;
		}
		else if (Sum == 6)
		{
			// Three O's on a row, opponent is winner
			retVal = Lost;
			return retVal;
		}
	}

	// Check first diagonal
	Sum = 0;
	Blanc = false;
	for (i=0;i<=2;++i)
	{
		Sum = Sum + TTTValues[i][i];
		if (TTTValues[i][i]==0){Blanc = true;}
	}
	if (Sum == 0)
	{
		// All field empty
	}
	else if (Sum == 3 & Blanc == false)
	{
		// Three X's on a row, EV3 is winner
		retVal = Won;
		return retVal;
	}
	else if (Sum == 6)
	{
		// Three O's on a row, opponent is winner
		retVal = Lost;
		return retVal;
	}

	// Check second diagonal
	Sum = 0;
	Blanc = false;
	for (i=0;i<=2;++i)
	{
		Sum = Sum + TTTValues[i][2-i];
		if (TTTValues[i][2-i]==0){Blanc = true;}
	}
	if (Sum == 0)
	{
		// All fields empty
	}
	else if (Sum == 3 & Blanc == false)
	{
		// Three X's on a row, EV3 is winner
		retVal = Won;
		return retVal;
	}
	else if (Sum == 6)
	{
		// Three O's on a row, opponent is winner
		retVal = Lost;
		return retVal;
	}

	if (Round < 8)
	{
		retVal = NextMove;	// No winner yet, so go to next move
	}
	else
	{
		retVal = Draw;		// No winner and no more moves, it's a draw!
	}

	return retVal;
}

////////////////////////////////////////////////////////////////////////////////
// Function to play Tic Tac Toe
// Based on algorithm described on: http://www.gliffy.com/publish/4867101
////////////////////////////////////////////////////////////////////////////////

int SimpleTTTAlg()
{
	int retVal=0;			// Returnvalue: 0= no error, 1=error during TwoinRow determination.
	int i,j,n;				// Counters
	int o = 0;				// Number of O's
	int x = 0;				// Number of X's
	int b = 0;				// Number of blancs
	int Row[9];				// Row[0,1,2] = value of field, Row[3,4,5] = corresponding row of field, Row[6,7,8] = column of field
	int Corner[4];		// Values of corner fields (Corner[0]=field(0,0), [1]=(0,2), [2]=(2,2), [3]=(2,0)
	int Cb = 0;				// Number of blanc in corner fields
	int Cx = 0;				// Number of X's in corner fields
	int Co = 0;				// Number of O's in corner fields
	int TwoinRow[8][7] = {
											{0,0,0,0,1,0,2},	// First column indicating player has two in a row (0=none, 1=EV3, 2=Opponent)
											{0,1,0,1,1,1,2},	// Other columns directing to corresponding fields of row/column/diagonal
											{0,2,0,2,1,2,2},
											{0,0,0,1,0,2,0},
											{0,0,1,1,1,2,1},
											{0,0,2,1,2,2,2},
											{0,0,0,1,1,2,2},
											{0,0,2,1,1,2,0}};

	// Step Ia: is there a chance on three on a row horizontally?
	for(i=0;i<=2;++i)
	{
		b = 0;
		x = 0;
		o = 0;
		for(j=0;j<=2;++j)
		{
			if(TTTValues[i][j] == 0)
			{
				b = b + 1;
				Row[j] = 0;
				Row[j+3] = i;
				Row[j+6] = j;
			}
			if(TTTValues[i][j] == 1)
			{
				x = x + 1;
				Row[j] = 1;
				Row[j+3] = i;
				Row[j+6] = j;

			}
			if(TTTValues[i][j] == 2)
			{
				o = o + 1;
				Row[j] = 2;
				Row[j+3] = i;
				Row[j+6] = j;
			}
		}
		writeDebugStreamLine("SimpleTTTAlg - Step Ia: row(%1d) - b=%1d, x=%1d, o=%1d",i,b,x,o);
		if (x == 2 & o == 0)
		{
			TwoinRow[i][0] = 1;
		}
		else if (o == 2 & x == 0)
		{
			TwoinRow[i][0] = 2;
		}
		else
		{
			TwoinRow[i][0] = 0;
		}
	}
	// Step Ib: is there a chance on three in a column?
	for(j=0;j<=2;++j)
	{
		b = 0;
		x = 0;
		o = 0;
		for(i=0;i<=2;++i)
		{
			if(TTTValues[i][j] == 0)
			{
				b = b + 1;
				Row[i] = 0;
				Row[i+3] = i;
				Row[i+6] = j;
			}
			if(TTTValues[i][j] == 1)
			{
				x = x + 1;
				Row[i] = 1;
				Row[i+3] = i;
				Row[i+6] = j;

			}
			if(TTTValues[i][j] == 2)
			{
				o = o + 1;
				Row[i] = 2;
				Row[i+3] = i;
				Row[i+6] = j;
			}
		}
		writeDebugStreamLine("SimpleTTTAlg - Step Ib: column(%1d) - b=%1d, x=%1d, o=%1d",j,b,x,o);
		if (x == 2 & o == 0)
		{
			TwoinRow[3+j][0] = 1;
		}
		else if (o == 2 & x == 0)
		{
			TwoinRow[3+j][0] = 2;
		}
		else
		{
			TwoinRow[3+j][0] = 0;
		}
	}
	// Step Ic: is there a chance on three on 1st diagonal?
	b = 0;
	x = 0;
	o = 0;
	for(i=0;i<=2;++i)
	{
		if(TTTValues[i][i] == 0)
		{
			b = b + 1;
			Row[i] = 0;
			Row[i+3] = i;
			Row[i+6] = j;
		}
		if(TTTValues[i][i] == 1)
		{
			x = x + 1;
			Row[i] = 1;
			Row[i+3] = i;
			Row[i+6] = j;
		}
		if(TTTValues[i][i] == 2)
		{
			o = o + 1;
			Row[i] = 2;
			Row[i+3] = i;
			Row[i+6] = j;
		}
	}
	writeDebugStreamLine("SimpleTTTAlg - Step Ic: 1st diagonal - b=%1d, x=%1d, o=%1d",b,x,o);
	if (x == 2 & o == 0)
	{
		TwoinRow[6][0] = 1;
	}
	else if (o == 2 & x == 0)
	{
		TwoinRow[6][0] = 2;
	}
	else
	{
		TwoinRow[6][0] = 0;
	}
	// Step Id: is there a chance on three on 2nd diagonal?
	b = 0;
	x = 0;
	o = 0;
	for(i=0;i<=2;++i)
	{
		if(TTTValues[i][2-i] == 0)
		{
			b = b + 1;
			Row[i] = 0;
			Row[i+3] = i;
			Row[i+6] = 2-i;
		}
		if(TTTValues[i][2-i] == 1)
		{
			x = x + 1;
			Row[i] = 1;
			Row[i+3] = i;
			Row[i+6] = 2-i;
		}
		if(TTTValues[i][2-i] == 2)
		{
			o = o + 1;
			Row[i] = 2;
			Row[i+3] = i;
			Row[i+6] = 2-i;
		}
	}
	writeDebugStreamLine("SimpleTTTAlg - Step Id: 2nd diagonal - b=%1d, x=%1d, o=%1d",b,x,o);
	if (x == 2 & o == 0)
	{
		TwoinRow[7][0] = 1;
	}
	else if (o == 2 & x == 0)
	{
		TwoinRow[7][0] = 2;
	}
	else
	{
		TwoinRow[7][0] = 0;
	}
	// Two on a row for EV3 and a blanc? Then finish the game!
	for (i=0;i<=7;++i)
	{
		if (TwoinRow[i][0] == 1)
		{
			for (j=0;j<=2;++j)
			{
				if (TTTValues[TwoinRow[i][2*j+1]][TwoinRow[i][2*j+2]] == 0)
				{
					DrawCross(TwoinRow[i][2*j+1],TwoinRow[i][2*j+2]);
					TTTValues[TwoinRow[i][2*j+1]][TwoinRow[i][2*j+2]] = 1;
					return retVal;
				}
				else if (TTTValues[TwoinRow[i][2*j+1]][TwoinRow[i][2*j+2]] == 2)
				{
					// Programming error: in this row EV3 should have 2 on a row and chance to win
					retVal = 1;
					return retVal;
				}
			}
		}
	}
	// Two on a row for opponent and a blanc? Then block to prevent from losing the game!
	for (i=0;i<=7;++i)
	{
		if (TwoinRow[i][0] == 2)
		{
			for (j=0;j<=2;++j)
			{
				if (TTTValues[TwoinRow[i][2*j+1]][TwoinRow[i][2*j+2]] == 0)
				{
					DrawCross(TwoinRow[i][2*j+1],TwoinRow[i][2*j+2]);
					TTTValues[TwoinRow[i][2*j+1]][TwoinRow[i][2*j+2]] = 1;
					return retVal;
				}
				else if (TTTValues[TwoinRow[i][2*j+1]][TwoinRow[i][2*j+2]] == 1)
				{
					// Programming error: in this row opponent should have 2 on a row and chance to win
					retVal = 1;
					return retVal;
				}
			}
		}
	}

	// Step II: is field (1,1) free, if so place cross
	writeDebugStreamLine("SimpleTTTAlg - Step II: Center field=%1d",TTTValues[1][1]);
	if (TTTValues[1][1] == 0)
	{
		DrawCross(1,1);
		return retVal;
	}

	// Step III: check all corner fields
	Corner[0] = TTTValues[0][0];
	Corner[1] = TTTValues[0][2];
	Corner[2] = TTTValues[2][2];
	Corner[3] = TTTValues[2][0];

	// Count values in corner fields
	for(i=0;i<=3;++i)
	{
		if (Corner[i] == 0) {Cb = Cb + 1;}
		if (Corner[i] == 1) {Cx = Cx + 1;}
		if (Corner[i] == 2) {Co = Co + 1;}
	}
	writeDebugStreamLine("SimpleTTTAlg - Step III: Cb=%1d, Cx=%1d, Co=%1d",Cb,Cx,Co);

	// If opponent occupies a corner field, place a cross in opposing field if possible
	if (Co >= 1)
	{
		for(i=0;i<=3;++i)
		{
			if (i == 0) {n = 2;}	// n = opposing corner
			if (i == 1) {n = 3;}
			if (i == 2) {n = 0;}
			if (i == 3) {n = 1;}

			if (Corner[i] == 2)		// Opponent occupies corner field
			{
				if (Corner[n] == 0)	// Opposing corner field is empty, place cross
				{
					if (n == 0) {DrawCross(0,0);return retVal;}
					if (n == 1) {DrawCross(0,2);return retVal;}
					if (n == 2) {DrawCross(2,2);return retVal;}
					if (n == 3) {DrawCross(2,0);return retVal;}
				}
			}
		}
		// No opposing corner field, place a cross in any free corner field
		for(i=0;i<=3;++i)
		{
			if (Corner[i] == 0)	// Empty corner field
			{
				if (i == 0) {DrawCross(0,0);return retVal;}
				if (i == 1) {DrawCross(0,2);return retVal;}
				if (i == 2) {DrawCross(2,2);return retVal;}
				if (i == 3) {DrawCross(2,0);return retVal;}
			}
		}
		// No corner field available, place a cross in any free field
		for (i=0;i<=2;++i)
		{
			for (j=0;j<=2;++j)
			{
				if (TTTValues[i][j] == 0)
				{
					DrawCross(i,j);
					return retVal;
				}
			}
		}
	}
	// If EV3 occupies a corner field, place a cross in opposing corner field
	else if (Cx >= 1)
	{
		for (i=0;i<=3;++i)
		{
			if (Corner[i] == 1)
			{
				if (i == 0) {DrawCross(2,2);return retVal;}
				if (i == 1) {DrawCross(2,0);return retVal;}
				if (i == 2) {DrawCross(0,0);return retVal;}
				if (i == 3) {DrawCross(0,2);return retVal;}
			}
		}
	}
	// No corner is occupied yet, place a cross in corner field
	DrawCross(0,0);
	return retVal;

}
